import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { profiles } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const onboardingDataSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  educationSystem: z.enum(["11", "12"]),
  targetUniversities: z.array(z.string()),
  programs: z.array(z.string()),
  goals: z.string(),
  interests: z.array(z.string()),
  bio: z.string(),
});

export const onboardingRouter = router({
  complete: protectedProcedure
    .input(onboardingDataSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        // Check if profile exists
        const existingProfile = await db
          .select()
          .from(profiles)
          .where(eq(profiles.userId, ctx.user.id))
          .limit(1);

        if (existingProfile.length > 0) {
          // Update existing profile
          await db
            .update(profiles)
            .set({
              educationSystem: input.educationSystem,
              targetUniversities: input.targetUniversities,
              programs: input.programs,
              goals: input.goals,
              interests: input.interests,
              bio: input.bio,
              onboardingCompleted: true,
              languagePreference: "en", // TODO: Get from user context
            })
            .where(eq(profiles.userId, ctx.user.id));
        } else {
          // Create new profile
          await db.insert(profiles).values({
            userId: ctx.user.id,
            educationSystem: input.educationSystem,
            targetUniversities: input.targetUniversities,
            programs: input.programs,
            goals: input.goals,
            interests: input.interests,
            bio: input.bio,
            onboardingCompleted: true,
            languagePreference: "en",
          });
        }

        return { success: true };
      } catch (error) {
        console.error("Error completing onboarding:", error);
        throw new Error("Failed to save onboarding data");
      }
    }),

  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return null;
    }

    try {
      const profile = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, ctx.user.id))
        .limit(1);

      return profile.length > 0 ? profile[0] : null;
    } catch (error) {
      console.error("Error fetching profile:", error);
      return null;
    }
  }),
});
