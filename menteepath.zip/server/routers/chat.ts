import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { chatHistory, dailyUsage } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { invokeLLM } from "../_core/llm";

const DAILY_MESSAGE_LIMIT = 10;

export const chatRouter = router({
  sendMessage: protectedProcedure
    .input(z.object({ message: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        // Check daily usage limit
        const today = new Date().toISOString().split("T")[0];
        const todayUsage = await db
          .select()
          .from(dailyUsage)
          .where(and(eq(dailyUsage.userId, ctx.user.id), eq(dailyUsage.date, today)))
          .limit(1);

        const messagesUsedToday = todayUsage.length > 0 ? (todayUsage[0].messagesUsed || 0) : 0;

        if (messagesUsedToday >= DAILY_MESSAGE_LIMIT) {
          throw new Error("Daily message limit reached");
        }

        // Call LLM to generate response
        const systemPrompt = `You are MenteePath, an expert university admissions advisor. You help students navigate their university admissions journey with personalized guidance, strategic advice, and encouragement.

Your role is to:
- Answer questions about university applications, essays, and interviews
- Provide strategic advice based on the student's background and goals
- Help with timeline planning and deadline management
- Offer encouragement and support throughout the process
- Suggest resources and next steps

Be conversational, supportive, and practical in your responses. Keep responses concise and actionable.`;

        const messages = [
          { role: "system" as const, content: systemPrompt },
          { role: "user" as const, content: input.message },
        ];

        const response = await invokeLLM({ messages });
        const assistantMessage = response.choices?.[0]?.message?.content || "I apologize, I couldn't generate a response. Please try again.";

        // Update chat history
        const existingChat = await db
          .select()
          .from(chatHistory)
          .where(eq(chatHistory.userId, ctx.user.id))
          .limit(1);

        const userMessage = {
          role: "user",
          content: input.message,
          timestamp: Date.now(),
        };

        const assistantMsg = {
          role: "assistant",
          content: assistantMessage,
          timestamp: Date.now(),
        };

        if (existingChat.length > 0) {
          const messages = existingChat[0].messages || [];
          await db
            .update(chatHistory)
            .set({
              messages: [...messages, userMessage, assistantMsg],
            })
            .where(eq(chatHistory.id, existingChat[0].id));
        } else {
          await db.insert(chatHistory).values({
            userId: ctx.user.id,
            messages: [userMessage, assistantMsg],
          });
        }

        // Update daily usage
        if (todayUsage.length > 0) {
          const usageRecord = todayUsage[0];
          if (usageRecord) {
            await db
              .update(dailyUsage)
              .set({ messagesUsed: (usageRecord.messagesUsed || 0) + 1 })
              .where(eq(dailyUsage.id, usageRecord.id));
          }
        } else {
          await db.insert(dailyUsage).values({
            userId: ctx.user.id,
            date: today,
            messagesUsed: 1,
          });
        }

        return {
          success: true,
          message: assistantMessage,
          messagesUsedToday: messagesUsedToday + 1,
        };
      } catch (error) {
        console.error("Error sending message:", error);
        throw error;
      }
    }),

  getHistory: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return { messages: [], messagesUsedToday: 0 };
    }

    try {
      const chat = await db
        .select()
        .from(chatHistory)
        .where(eq(chatHistory.userId, ctx.user.id))
        .limit(1);

      const today = new Date().toISOString().split("T")[0];
      const todayUsage = await db
        .select()
        .from(dailyUsage)
        .where(and(eq(dailyUsage.userId, ctx.user.id), eq(dailyUsage.date, today)))
        .limit(1);

      return {
        messages: chat.length > 0 ? chat[0].messages : [],
        messagesUsedToday: todayUsage.length > 0 ? (todayUsage[0].messagesUsed || 0) : 0,
      };
    } catch (error) {
      console.error("Error fetching chat history:", error);
      return { messages: [], messagesUsedToday: 0 };
    }
  }),

  getDailyLimit: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return { limit: DAILY_MESSAGE_LIMIT, used: 0 };
    }

    try {
      const today = new Date().toISOString().split("T")[0];
      const todayUsage = await db
        .select()
        .from(dailyUsage)
        .where(and(eq(dailyUsage.userId, ctx.user.id), eq(dailyUsage.date, today)))
        .limit(1);

      return {
        limit: DAILY_MESSAGE_LIMIT,
        used: todayUsage.length > 0 ? (todayUsage[0].messagesUsed || 0) : 0,
      };
    } catch (error) {
      console.error("Error fetching daily limit:", error);
      return { limit: DAILY_MESSAGE_LIMIT, used: 0 };
    }
  }),
});
