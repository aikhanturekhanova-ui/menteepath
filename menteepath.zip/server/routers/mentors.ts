import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { mentors, mentorRequests } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const mentorsRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        search: z.string().optional(),
        university: z.string().optional(),
        program: z.string().optional(),
      })
    )
    .query(async () => {
      // Return sample mentors for now
      return [
        {
          id: 1,
          userId: 0,
          name: "Sarah Chen",
          university: "Harvard University",
          program: "Computer Science",
          expertise: ["AI/ML", "Web Development"],
          bio: "Graduated with honors, now at Google",
          rating: 4.9,
          isVerified: true,
          yearsOfExperience: 2,
          createdAt: new Date(),
        },
      ];
    }),

  sendRequest: protectedProcedure
    .input(z.object({ mentorId: z.number(), message: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        const existingRequest = await db
          .select()
          .from(mentorRequests)
          .where(
            and(
              eq(mentorRequests.menteeId, ctx.user.id),
              eq(mentorRequests.mentorId, input.mentorId)
            )
          )
          .limit(1);

        if (existingRequest.length > 0) {
          throw new Error("Request already sent");
        }

        await db.insert(mentorRequests).values({
          menteeId: ctx.user.id,
          mentorId: input.mentorId,
          message: input.message,
          status: "pending",
        });

        return { success: true };
      } catch (error) {
        console.error("Error sending mentor request:", error);
        throw error;
      }
    }),

  getRequests: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return [];
    }

    try {
      const requests = await db
        .select()
        .from(mentorRequests)
        .where(eq(mentorRequests.menteeId, ctx.user.id));

      return requests;
    } catch (error) {
      console.error("Error fetching mentor requests:", error);
      return [];
    }
  }),

  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return null;
    }

    try {
      const mentorProfile = await db
        .select()
        .from(mentors)
        .where(eq(mentors.userId, ctx.user.id))
        .limit(1);

      return mentorProfile.length > 0 ? mentorProfile[0] : null;
    } catch (error) {
      console.error("Error fetching mentor profile:", error);
      return null;
    }
  }),

  createProfile: protectedProcedure
    .input(
      z.object({
        university: z.string(),
        program: z.string(),
        expertise: z.array(z.string()),
        bio: z.string(),
        yearsOfExperience: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        const existingProfile = await db
          .select()
          .from(mentors)
          .where(eq(mentors.userId, ctx.user.id))
          .limit(1);

        if (existingProfile.length > 0) {
          await db
            .update(mentors)
            .set({
              university: input.university,
              program: input.program,
              expertise: input.expertise,
              bio: input.bio,
              yearsOfExperience: input.yearsOfExperience,
            })
            .where(eq(mentors.userId, ctx.user.id));
        } else {
          await db.insert(mentors).values({
            userId: ctx.user.id,
            university: input.university,
            program: input.program,
            expertise: input.expertise,
            bio: input.bio,
            yearsOfExperience: input.yearsOfExperience,
          });
        }

        return { success: true };
      } catch (error) {
        console.error("Error creating mentor profile:", error);
        throw error;
      }
    }),
});
