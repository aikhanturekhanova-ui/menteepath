import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { roadmaps, profiles } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import { invokeLLM } from "../_core/llm";

export const roadmapRouter = router({
  generate: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    try {
      // Get user profile for context
      const userProfile = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, ctx.user.id))
        .limit(1);

      if (userProfile.length === 0) {
        throw new Error("User profile not found. Complete onboarding first.");
      }

      const profile = userProfile[0];

      // Generate AI-powered roadmap
      const systemPrompt = `You are an expert university admissions advisor. Generate a personalized step-by-step roadmap for a student's university admissions journey.

Return a JSON array of steps with this exact structure:
[
  {
    "name": "Step name",
    "daysFromNow": number (days until deadline),
    "successProof": "URL or description of how to verify completion",
    "order": number
  }
]

Generate 5-7 realistic steps based on the student's profile. Be specific and actionable.`;

      const userPrompt = `Create an admissions roadmap for:
- Target Universities: ${profile.targetUniversities?.join(", ") || "Not specified"}
- Programs: ${profile.programs?.join(", ") || "Not specified"}
- Education System: ${profile.educationSystem === "11" ? "11 years (IB/A-Levels)" : "12 years (AP/High School)"}
- Interests: ${profile.interests?.join(", ") || "Not specified"}`;

      const messages = [
        { role: "system" as const, content: systemPrompt },
        { role: "user" as const, content: userPrompt },
      ];

      const response = await invokeLLM({
        messages,
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "roadmap_steps",
            strict: true,
            schema: {
              type: "object",
              properties: {
                steps: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      daysFromNow: { type: "number" },
                      successProof: { type: "string" },
                      order: { type: "number" },
                    },
                    required: ["name", "daysFromNow", "successProof", "order"],
                  },
                },
              },
              required: ["steps"],
            },
          },
        },
      });

      let generatedSteps = [];
      try {
        const content = response.choices?.[0]?.message?.content;
        if (typeof content === "string") {
          const parsed = JSON.parse(content);
          generatedSteps = parsed.steps.map((step: any, idx: number) => ({
            id: nanoid(),
            name: step.name,
            deadline: Date.now() + step.daysFromNow * 24 * 60 * 60 * 1000,
            successProof: step.successProof,
            completed: false,
            order: idx + 1,
          }));
        }
      } catch (e) {
        console.error("Error parsing AI response:", e);
      }

      // Fallback to sample roadmap if parsing fails
      if (generatedSteps.length === 0) {
        const now = Date.now();
        generatedSteps = [
          {
            id: nanoid(),
            name: "Register for standardized tests (IELTS/TOEFL)",
            deadline: now + 30 * 24 * 60 * 60 * 1000,
            successProof: "Test registration confirmation",
            completed: false,
            order: 1,
          },
          {
            id: nanoid(),
            name: "Prepare test materials and practice",
            deadline: now + 60 * 24 * 60 * 60 * 1000,
            successProof: "Practice test scores",
            completed: false,
            order: 2,
          },
          {
            id: nanoid(),
            name: "Take official standardized tests",
            deadline: now + 90 * 24 * 60 * 60 * 1000,
            successProof: "Official test scores",
            completed: false,
            order: 3,
          },
          {
            id: nanoid(),
            name: "Start university applications",
            deadline: now + 120 * 24 * 60 * 60 * 1000,
            successProof: "Application submissions",
            completed: false,
            order: 4,
          },
          {
            id: nanoid(),
            name: "Complete essays and personal statements",
            deadline: now + 150 * 24 * 60 * 60 * 1000,
            successProof: "Completed essay drafts",
            completed: false,
            order: 5,
          },
        ];
      }

      // Check if roadmap exists
      const existingRoadmap = await db
        .select()
        .from(roadmaps)
        .where(eq(roadmaps.userId, ctx.user.id))
        .limit(1);

      if (existingRoadmap.length > 0) {
        await db
          .update(roadmaps)
          .set({ steps: generatedSteps })
          .where(eq(roadmaps.userId, ctx.user.id));
      } else {
        await db.insert(roadmaps).values({
          userId: ctx.user.id,
          steps: generatedSteps,
        });
      }

      return { success: true, steps: generatedSteps };
    } catch (error) {
      console.error("Error generating roadmap:", error);
      throw error;
    }
  }),

  get: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      return null;
    }

    try {
      const roadmap = await db
        .select()
        .from(roadmaps)
        .where(eq(roadmaps.userId, ctx.user.id))
        .limit(1);

      return roadmap.length > 0 ? roadmap[0] : null;
    } catch (error) {
      console.error("Error fetching roadmap:", error);
      return null;
    }
  }),

  updateStep: protectedProcedure
    .input(
      z.object({
        stepId: z.string(),
        completed: z.boolean(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        const roadmap = await db
          .select()
          .from(roadmaps)
          .where(eq(roadmaps.userId, ctx.user.id))
          .limit(1);

        if (roadmap.length === 0) {
          throw new Error("Roadmap not found");
        }

        const currentRoadmap = roadmap[0];
        const updatedSteps = (currentRoadmap.steps || []).map((step: any) =>
          step.id === input.stepId ? { ...step, completed: input.completed } : step
        );

        if (currentRoadmap) {
          await db
            .update(roadmaps)
            .set({ steps: updatedSteps })
            .where(eq(roadmaps.userId, ctx.user.id));
        }

        return { success: true };
      } catch (error) {
        console.error("Error updating roadmap step:", error);
        throw error;
      }
    }),
});
