import { useState, useEffect, useRef } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Loader2, Send, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Streamdown } from 'streamdown';
import { trpc } from '@/lib/trpc';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export default function Chat() {
  const { t } = useI18n();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messagesUsed, setMessagesUsed] = useState(0);
  const [dailyLimit, setDailyLimit] = useState(10);
  const [limitReached, setLimitReached] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: chatData } = trpc.chat.getHistory.useQuery();
  const { data: limitData } = trpc.chat.getDailyLimit.useQuery();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (chatData?.messages) {
      setMessages(chatData.messages.map((msg: any, idx: number) => ({
        id: `${idx}`,
        role: msg.role,
        content: msg.content,
        timestamp: msg.timestamp || Date.now(),
      })));
    }
  }, [chatData]);

  useEffect(() => {
    if (limitData) {
      setMessagesUsed(limitData.used);
      setDailyLimit(limitData.limit);
      setLimitReached(limitData.used >= limitData.limit);
    }
  }, [limitData]);

  const handleSendMessage = async () => {
    if (!input.trim() || loading || limitReached) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await sendMessageMutation.mutateAsync({
        message: input,
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.message,
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, assistantMessage]);
      setMessagesUsed(response.messagesUsedToday);
      if (response.messagesUsedToday >= dailyLimit) {
        setLimitReached(true);
      }
    } catch (error: any) {
      console.error('Error sending message:', error);
      if (error.message?.includes('Daily message limit')) {
        setLimitReached(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">{t('chat.title')}</h1>
            <p className="text-muted-foreground">{t('chat.subtitle')}</p>
          </div>

          {/* Usage Indicator */}
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline">
                {messagesUsed}/{dailyLimit} {t('common.messages')}
              </Badge>
            </div>
            {limitReached && (
              <div className="flex items-center gap-2 text-destructive">
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">{t('chat.limit_reached')}</span>
              </div>
            )}
          </div>

          {/* Chat Container */}
          <Card className="border-border/50 bg-card/50 flex flex-col h-[600px]">
            {/* Messages Area */}
            <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.length === 0 ? (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <p>{t('chat.empty_state')}</p>
                  </div>
                </div>
              ) : (
                <>
                  {messages.map((message, idx) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: idx * 0.05 }}
                      className={`flex ${
                        message.role === 'user' ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          message.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-card border border-border/50'
                        }`}
                      >
                        {message.role === 'assistant' ? (
                          <Streamdown>{message.content}</Streamdown>
                        ) : (
                          <p>{message.content}</p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {loading && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex justify-start"
                    >
                      <div className="bg-card border border-border/50 px-4 py-2 rounded-lg flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">{t('chat.loading')}</span>
                      </div>
                    </motion.div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              )}
            </CardContent>

            {/* Input Area */}
            <div className="border-t border-border/50 p-6 bg-card/30">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={t('chat.placeholder')}
                  disabled={loading || limitReached}
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={loading || limitReached || !input.trim()}
                  className="gap-2 bg-blue-600 hover:bg-blue-700"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  {t('chat.send')}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  );
}
