import { useI18n } from '@/contexts/I18nContext';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { getLoginUrl } from '@/const';
import { Sparkles, MessageSquare, MapPin, Users, CheckCircle2, ArrowRight } from 'lucide-react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';

export default function Home() {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      setLocation('/onboarding');
    } else {
      window.location.href = getLoginUrl();
      // After login, user will be redirected to /api/oauth/callback which handles redirect
    }
  };

  const features = [
    {
      icon: Sparkles,
      title: t('landing.feature_ai_title'),
      description: t('landing.feature_ai_desc'),
    },
    {
      icon: MapPin,
      title: t('landing.feature_roadmap_title'),
      description: t('landing.feature_roadmap_desc'),
    },
    {
      icon: Users,
      title: t('landing.feature_mentors_title'),
      description: t('landing.feature_mentors_desc'),
    },
    {
      icon: CheckCircle2,
      title: t('landing.feature_data_title'),
      description: t('landing.feature_data_desc'),
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg">{t('landing.title')}</span>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            {isAuthenticated ? (
              <Button onClick={() => setLocation('/dashboard')}>
                {t('nav.dashboard')}
              </Button>
            ) : (
              <Button onClick={() => window.location.href = getLoginUrl()}>
                {t('common.login')}
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-border/50 bg-card/50 mb-6">
            <Sparkles className="w-4 h-4 text-blue-500" />
            <span className="text-sm text-muted-foreground">{t('landing.hero_tagline')}</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 bg-clip-text text-transparent">
            {t('landing.title')}
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground mb-8">
            {t('landing.description')}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={handleGetStarted}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              {t('landing.cta_primary')}
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
            >
              {t('landing.cta_secondary')}
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Features Section - Bento Grid */}
      <section id="features" className="container py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {t('landing.features_title')}
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            {t('landing.description')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full border-border/50 hover:border-border/100 transition-colors bg-card/50 hover:bg-card/80 backdrop-blur-sm">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-blue-500" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Data Transparency Section */}
      <section className="container py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-card/50 border border-border/50 rounded-2xl p-8 md:p-12 backdrop-blur-sm"
        >
          <div className="max-w-2xl mx-auto text-center">
            <CheckCircle2 className="w-12 h-12 text-blue-500 mx-auto mb-6" />
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              {t('landing.transparency_section')}
            </h3>
            <p className="text-muted-foreground text-lg">
              {t('landing.transparency_desc')}
            </p>
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="container py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-blue-600/20 to-blue-500/20 border border-blue-500/30 rounded-2xl p-8 md:p-16 text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {t('landing.cta_section_title')}
          </h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            {t('landing.cta_section_desc')}
          </p>
          <Button
            size="lg"
            onClick={handleGetStarted}
            className="gap-2 bg-blue-600 hover:bg-blue-700"
          >
            {t('landing.cta_primary')}
            <ArrowRight className="w-4 h-4" />
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 mt-20">
        <div className="container text-center text-muted-foreground text-sm">
          {t('landing.footer_copyright')}
        </div>
      </footer>
    </div>
  );
}
