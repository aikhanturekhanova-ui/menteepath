import { useI18n } from '@/contexts/I18nContext';
import { useAuth } from '@/_core/hooks/useAuth';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useLocation } from 'wouter';
import {
  MessageSquare,
  MapPin,
  Users,
  Calendar,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function Dashboard() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const roadmapProgress = 35;
  const upcomingDeadlines = [
    { name: 'IELTS Registration', date: '2026-05-15' },
    { name: 'SAT Exam', date: '2026-06-20' },
  ];

  const recentChats = [
    { id: 1, title: 'About Harvard CS Program', date: '2 hours ago' },
    { id: 2, title: 'How to improve my GPA?', date: '1 day ago' },
  ];

  const recommendedMentors = [
    { id: 1, name: 'Sarah Chen', university: 'Harvard', program: 'CS' },
    { id: 2, name: 'James Wilson', university: 'MIT', program: 'EE' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 },
    },
  };

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold mb-2">
              {t('dashboard.title', '', { name: user?.name || 'User' })}
            </h1>
            <p className="text-muted-foreground text-lg">{t('dashboard.subtitle')}</p>
          </div>

          {/* Bento Grid Layout */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-max"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Large Card: Roadmap Progress */}
            <motion.div variants={itemVariants} className="md:col-span-2 lg:col-span-2">
              <Card className="border-border/50 bg-gradient-to-br from-card/50 to-card/30 h-full">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-blue-500" />
                        {t('dashboard.roadmap_progress')}
                      </CardTitle>
                      <CardDescription>Your admissions journey</CardDescription>
                    </div>
                    <span className="text-3xl font-bold text-blue-500">{roadmapProgress}%</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Overall Progress</span>
                      <span className="text-muted-foreground">7/20 tasks completed</span>
                    </div>
                    <Progress value={roadmapProgress} className="h-2" />
                  </div>
                  <Button
                    onClick={() => setLocation('/roadmap')}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    View Roadmap
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Medium Card: Upcoming Deadlines */}
            <motion.div variants={itemVariants} className="md:col-span-1 lg:col-span-1">
              <Card className="border-border/50 bg-card/50 h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calendar className="w-5 h-5 text-orange-500" />
                    {t('dashboard.upcoming_deadlines')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {upcomingDeadlines.length > 0 ? (
                    <>
                      {upcomingDeadlines.map((deadline, idx) => (
                        <div key={idx} className="text-sm">
                          <p className="font-medium">{deadline.name}</p>
                          <p className="text-xs text-muted-foreground">{deadline.date}</p>
                        </div>
                      ))}
                      <Button
                        onClick={() => setLocation('/roadmap')}
                        variant="ghost"
                        size="sm"
                        className="w-full mt-2"
                      >
                        {t('dashboard.view_all')}
                      </Button>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t('dashboard.no_deadlines')}</p>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Medium Card: AI Chat */}
            <motion.div variants={itemVariants} className="md:col-span-1 lg:col-span-1">
              <Card className="border-border/50 bg-card/50 h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Sparkles className="w-5 h-5 text-purple-500" />
                    AI Assistant
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <p className="font-medium">Daily Messages</p>
                    <p className="text-xs text-muted-foreground">3/10 used today</p>
                  </div>
                  <Button
                    onClick={() => setLocation('/chat')}
                    className="w-full gap-2 bg-purple-600 hover:bg-purple-700"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Ask AI
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Large Card: Recent Chats */}
            <motion.div variants={itemVariants} className="md:col-span-2 lg:col-span-2">
              <Card className="border-border/50 bg-card/50 h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-blue-500" />
                    {t('dashboard.recent_chats')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentChats.length > 0 ? (
                    <>
                      {recentChats.map((chat) => (
                        <div
                          key={chat.id}
                          className="p-3 rounded-lg bg-background/50 border border-border/50 hover:border-border transition-colors cursor-pointer"
                        >
                          <p className="text-sm font-medium">{chat.title}</p>
                          <p className="text-xs text-muted-foreground">{chat.date}</p>
                        </div>
                      ))}
                      <Button
                        onClick={() => setLocation('/chat')}
                        variant="ghost"
                        size="sm"
                        className="w-full"
                      >
                        {t('dashboard.view_all')}
                      </Button>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t('dashboard.no_chats')}</p>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Medium Card: Recommended Mentors */}
            <motion.div variants={itemVariants} className="md:col-span-2 lg:col-span-2">
              <Card className="border-border/50 bg-card/50 h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-green-500" />
                    {t('dashboard.recommended_mentors')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recommendedMentors.length > 0 ? (
                    <>
                      {recommendedMentors.map((mentor) => (
                        <div
                          key={mentor.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                        >
                          <div>
                            <p className="text-sm font-medium">{mentor.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {mentor.program} @ {mentor.university}
                            </p>
                          </div>
                          <Badge variant="outline">Connect</Badge>
                        </div>
                      ))}
                      <Button
                        onClick={() => setLocation('/mentors')}
                        variant="ghost"
                        size="sm"
                        className="w-full"
                      >
                        {t('dashboard.view_all')}
                      </Button>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t('dashboard.no_mentors')}</p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </ProtectedRoute>
  );
}
