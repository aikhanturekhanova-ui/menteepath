import { useState, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, CheckCircle2, Circle, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { trpc } from '@/lib/trpc';

interface RoadmapStep {
  id: string;
  name: string;
  deadline: number;
  successProof: string;
  completed: boolean;
  order: number;
}

export default function Roadmap() {
  const { t } = useI18n();
  const [steps, setSteps] = useState<RoadmapStep[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const { data: roadmapData } = trpc.roadmap.get.useQuery();
  const generateMutation = trpc.roadmap.generate.useMutation();
  const updateStepMutation = trpc.roadmap.updateStep.useMutation();

  useEffect(() => {
    if (roadmapData?.steps) {
      setSteps(roadmapData.steps);
      setLoading(false);
    } else if (!loading) {
      setLoading(false);
    }
  }, [roadmapData]);

  const handleToggleStep = async (stepId: string) => {
    const step = steps.find(s => s.id === stepId);
    if (!step) return;
    
    setSteps(prev =>
      prev.map(s =>
        s.id === stepId ? { ...s, completed: !s.completed } : s
      )
    );
    
    try {
      await updateStepMutation.mutateAsync({
        stepId,
        completed: !step.completed,
      });
    } catch (error) {
      console.error('Error updating step:', error);
      setSteps(prev =>
        prev.map(s =>
          s.id === stepId ? { ...s, completed: step.completed } : s
        )
      );
    }
  };

  const handleGenerateRoadmap = async () => {
    setGenerating(true);
    try {
      const result = await generateMutation.mutateAsync();
      setSteps(result.steps);
    } catch (error) {
      console.error('Error generating roadmap:', error);
    } finally {
      setGenerating(false);
    }
  };

  const completedCount = steps.filter(s => s.completed).length;
  const progressPercentage = steps.length > 0 ? (completedCount / steps.length) * 100 : 0;

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background text-foreground py-8 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">{t('roadmap.title')}</h1>
            <p className="text-muted-foreground">{t('roadmap.subtitle')}</p>
          </div>

          {/* Progress Bar */}
          {steps.length > 0 && (
            <Card className="border-border/50 bg-card/50 mb-8">
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">
                      {t('roadmap.progress', '', {
                        completed: completedCount,
                        total: steps.length,
                      })}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {Math.round(progressPercentage)}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${progressPercentage}%` }}
                      transition={{ duration: 0.5 }}
                      className="h-full bg-blue-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Steps Timeline */}
          {steps.length > 0 ? (
            <div className="space-y-4">
              {steps.map((step, idx) => {
                const deadline = new Date(step.deadline);
                const isOverdue = deadline < new Date();

                return (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: idx * 0.1 }}
                  >
                    <Card className="border-border/50 bg-card/50 hover:bg-card/80 transition-colors">
                      <CardContent className="pt-6">
                        <div className="flex gap-4">
                          {/* Checkbox */}
                          <div className="flex-shrink-0 pt-1">
                            <Checkbox
                              checked={step.completed}
                              onCheckedChange={() => handleToggleStep(step.id)}
                              className="w-6 h-6"
                            />
                          </div>

                          {/* Content */}
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1">
                                <h3
                                  className={`font-semibold text-lg ${
                                    step.completed ? 'line-through text-muted-foreground' : ''
                                  }`}
                                >
                                  {step.name}
                                </h3>
                                <div className="flex items-center gap-2 mt-2 flex-wrap">
                                  <Badge
                                    variant={isOverdue ? 'destructive' : 'outline'}
                                    className="text-xs"
                                  >
                                    {t('roadmap.task_deadline', '', {
                                      date: deadline.toLocaleDateString(),
                                    })}
                                  </Badge>
                  {step.successProof && (
                    <a
                      href={step.successProof}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs text-blue-500 hover:text-blue-600"
                    >
                      View Resource
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                                </div>
                              </div>

                              {/* Status Icon */}
                              <div className="flex-shrink-0">
                                {step.completed ? (
                                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                                ) : (
                                  <Circle className="w-6 h-6 text-muted-foreground" />
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <Card className="border-border/50 bg-card/50">
              <CardContent className="pt-6 text-center py-12">
                <p className="text-muted-foreground mb-4">{t('roadmap.empty_state')}</p>
                <Button
                  onClick={handleGenerateRoadmap}
                  disabled={generating}
                  className="gap-2 bg-blue-600 hover:bg-blue-700"
                >
                  {generating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      {t('roadmap.generating')}
                    </>
                  ) : (
                    'Generate Roadmap'
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
