import { useState } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { useAuth } from '@/_core/hooks/useAuth';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

interface OnboardingData {
  name: string;
  email: string;
  educationSystem: '11' | '12' | '';
  targetUniversities: string[];
  programs: string[];
  goals: string;
  interests: string[];
  bio: string;
}

export default function Onboarding() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [newUniversity, setNewUniversity] = useState('');
  const [newProgram, setNewProgram] = useState('');
  const [newInterest, setNewInterest] = useState('');

  const [data, setData] = useState<OnboardingData>({
    name: user?.name || '',
    email: user?.email || '',
    educationSystem: '',
    targetUniversities: [],
    programs: [],
    goals: '',
    interests: [],
    bio: '',
  });

  const handleInputChange = (field: keyof OnboardingData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const addUniversity = () => {
    if (newUniversity.trim()) {
      setData(prev => ({
        ...prev,
        targetUniversities: [...prev.targetUniversities, newUniversity.trim()],
      }));
      setNewUniversity('');
    }
  };

  const removeUniversity = (index: number) => {
    setData(prev => ({
      ...prev,
      targetUniversities: prev.targetUniversities.filter((_, i) => i !== index),
    }));
  };

  const addProgram = () => {
    if (newProgram.trim()) {
      setData(prev => ({
        ...prev,
        programs: [...prev.programs, newProgram.trim()],
      }));
      setNewProgram('');
    }
  };

  const removeProgram = (index: number) => {
    setData(prev => ({
      ...prev,
      programs: prev.programs.filter((_, i) => i !== index),
    }));
  };

  const addInterest = () => {
    if (newInterest.trim()) {
      setData(prev => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()],
      }));
      setNewInterest('');
    }
  };

  const removeInterest = (index: number) => {
    setData(prev => ({
      ...prev,
      interests: prev.interests.filter((_, i) => i !== index),
    }));
  };

  const handleNext = () => {
    if (step < 5) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const [, setLocation] = useLocation();
  const completeOnboarding = trpc.onboarding.complete.useMutation();

  const handleSubmit = async () => {
    if (!data.educationSystem) {
      toast.error('Please select education system');
      return;
    }
    setLoading(true);
    try {
      await completeOnboarding.mutateAsync({
        ...data,
        educationSystem: data.educationSystem as '11' | '12',
      });
      toast.success(t('onboarding.success_message'));
      setLocation('/dashboard');
    } catch (error) {
      console.error('Error saving onboarding data:', error);
      toast.error(t('onboarding.error_message'));
    } finally {
      setLoading(false);
    }
  };


  const steps = [
    { number: 1, title: t('onboarding.step_1_title'), desc: t('onboarding.step_1_desc') },
    { number: 2, title: t('onboarding.step_2_title'), desc: t('onboarding.step_2_desc') },
    { number: 3, title: t('onboarding.step_3_title'), desc: t('onboarding.step_3_desc') },
    { number: 4, title: t('onboarding.step_4_title'), desc: t('onboarding.step_4_desc') },
    { number: 5, title: t('onboarding.step_5_title'), desc: t('onboarding.step_5_desc') },
  ];

  const isFormValid = () => {
    if (step === 1) return data.name && data.email && data.educationSystem;
    if (step === 2) return data.targetUniversities.length > 0;
    if (step === 3) return data.programs.length > 0 && data.goals;
    if (step === 4) return data.interests.length > 0 && data.bio;
    return true;
  };

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-2xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">{t('onboarding.title')}</h1>
            <p className="text-muted-foreground">{t('onboarding.subtitle')}</p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex gap-2 mb-4">
              {steps.map((s, idx) => (
                <motion.div
                  key={s.number}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex-1"
                >
                  <div
                    className={`h-2 rounded-full transition-colors ${
                      step >= s.number ? 'bg-blue-500' : 'bg-border'
                    }`}
                  />
                </motion.div>
              ))}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">
                {t('onboarding.step_1_title')}
              </span>
              <span className="text-sm text-muted-foreground">
                {step} / {steps.length}
              </span>
            </div>
          </div>

          {/* Form Card */}
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <CardTitle>{steps[step - 1].title}</CardTitle>
                <CardDescription>{steps[step - 1].desc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Step 1: Basic Info */}
                {step === 1 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">{t('onboarding.name_label')}</Label>
                      <Input
                        id="name"
                        value={data.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="John Doe"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">{t('onboarding.email_label')}</Label>
                      <Input
                        id="email"
                        type="email"
                        value={data.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="john@example.com"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="education">{t('onboarding.education_system_label')}</Label>
                      <Select
                        value={data.educationSystem}
                        onValueChange={(value) => handleInputChange('educationSystem', value)}
                      >
                        <SelectTrigger id="education" className="mt-2">
                          <SelectValue placeholder="Select education system" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="11">{t('onboarding.education_system_11')}</SelectItem>
                          <SelectItem value="12">{t('onboarding.education_system_12')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Step 2: Target Universities */}
                {step === 2 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="university">{t('onboarding.universities_label')}</Label>
                      <div className="flex gap-2 mt-2">
                        <Input
                          id="university"
                          value={newUniversity}
                          onChange={(e) => setNewUniversity(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && addUniversity()}
                          placeholder={t('onboarding.universities_placeholder')}
                        />
                        <Button onClick={addUniversity} variant="outline">
                          {t('common.save')}
                        </Button>
                      </div>
                    </div>
                    {data.targetUniversities.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {data.targetUniversities.map((uni, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => removeUniversity(idx)}
                          >
                            {uni} ×
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Step 3: Programs & Goals */}
                {step === 3 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="programs">{t('onboarding.programs_label')}</Label>
                      <div className="flex gap-2 mt-2">
                        <Input
                          id="programs"
                          value={newProgram}
                          onChange={(e) => setNewProgram(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && addProgram()}
                          placeholder={t('onboarding.programs_placeholder')}
                        />
                        <Button onClick={addProgram} variant="outline">
                          {t('common.save')}
                        </Button>
                      </div>
                    </div>
                    {data.programs.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {data.programs.map((prog, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => removeProgram(idx)}
                          >
                            {prog} ×
                          </Badge>
                        ))}
                      </div>
                    )}
                    <div>
                      <Label htmlFor="goals">{t('onboarding.goals_label')}</Label>
                      <Textarea
                        id="goals"
                        value={data.goals}
                        onChange={(e) => handleInputChange('goals', e.target.value)}
                        placeholder={t('onboarding.goals_placeholder')}
                        className="mt-2"
                        rows={4}
                      />
                    </div>
                  </div>
                )}

                {/* Step 4: Background & Interests */}
                {step === 4 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="interests">{t('onboarding.interests_label')}</Label>
                      <div className="flex gap-2 mt-2">
                        <Input
                          id="interests"
                          value={newInterest}
                          onChange={(e) => setNewInterest(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && addInterest()}
                          placeholder={t('onboarding.interests_placeholder')}
                        />
                        <Button onClick={addInterest} variant="outline">
                          {t('common.save')}
                        </Button>
                      </div>
                    </div>
                    {data.interests.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {data.interests.map((interest, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="cursor-pointer"
                            onClick={() => removeInterest(idx)}
                          >
                            {interest} ×
                          </Badge>
                        ))}
                      </div>
                    )}
                    <div>
                      <Label htmlFor="bio">{t('onboarding.bio_label')}</Label>
                      <Textarea
                        id="bio"
                        value={data.bio}
                        onChange={(e) => handleInputChange('bio', e.target.value)}
                        placeholder={t('onboarding.bio_placeholder')}
                        className="mt-2"
                        rows={4}
                      />
                    </div>
                  </div>
                )}

                {/* Step 5: Review */}
                {step === 5 && (
                  <div className="space-y-4">
                    <div className="bg-card border border-border/50 rounded-lg p-4 space-y-3">
                      <div>
                        <span className="text-sm text-muted-foreground">{t('onboarding.name_label')}</span>
                        <p className="font-medium">{data.name}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">{t('onboarding.email_label')}</span>
                        <p className="font-medium">{data.email}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">{t('onboarding.education_system_label')}</span>
                        <p className="font-medium">{data.educationSystem}-year system</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">{t('onboarding.universities_label')}</span>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {data.targetUniversities.map((uni, idx) => (
                            <Badge key={idx}>{uni}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">{t('onboarding.programs_label')}</span>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {data.programs.map((prog, idx) => (
                            <Badge key={idx}>{prog}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Navigation Buttons */}
          <div className="flex gap-4 mt-8">
            <Button
              onClick={handleBack}
              variant="outline"
              disabled={step === 1}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              {t('common.back')}
            </Button>
            <Button
              onClick={step === 5 ? handleSubmit : handleNext}
              disabled={loading || !isFormValid()}
              className="flex-1 gap-2 bg-blue-600 hover:bg-blue-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {t('onboarding.completing')}
                </>
              ) : step === 5 ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  {t('common.submit')}
                </>
              ) : (
                <>
                  {t('common.next')}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
}
