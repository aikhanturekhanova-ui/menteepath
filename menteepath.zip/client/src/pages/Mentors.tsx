import { useState, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Loader2, Star, MessageSquare, Filter } from 'lucide-react';
import { motion } from 'framer-motion';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface Mentor {
  id: number;
  name: string;
  university: string;
  program: string;
  expertise: string[];
  bio: string;
  rating: number;
  isVerified: boolean;
  yearsOfExperience: number;
}

export default function Mentors() {
  const { t } = useI18n();
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterUniversity, setFilterUniversity] = useState('');
  const [filterProgram, setFilterProgram] = useState('');
  const [connecting, setConnecting] = useState<number | null>(null);

  const { data: mentorsList } = trpc.mentors.list.useQuery({
    search: searchQuery,
    university: filterUniversity,
    program: filterProgram,
  });
  const sendRequestMutation = trpc.mentors.sendRequest.useMutation();

  useEffect(() => {
    if (mentorsList) {
      setMentors(mentorsList);
      setLoading(false);
    }
  }, [mentorsList]);

  const handleConnect = async (mentorId: number) => {
    setConnecting(mentorId);
    try {
      await sendRequestMutation.mutateAsync({
        mentorId,
        message: 'I would like to connect with you for guidance on my university applications.',
      });
      toast.success('Request sent successfully!');
    } catch (error: any) {
      if (error.message?.includes('already sent')) {
        toast.error('You already sent a request to this mentor');
      } else {
        toast.error('Failed to send request');
      }
    } finally {
      setConnecting(null);
    }
  };

  const filteredMentors = mentors.filter(mentor => {
    const matchesSearch =
      mentor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mentor.expertise.some(e => e.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesUniversity = !filterUniversity || mentor.university.includes(filterUniversity);
    const matchesProgram = !filterProgram || mentor.program.includes(filterProgram);

    return matchesSearch && matchesUniversity && matchesProgram;
  });



  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">{t('mentors.title')}</h1>
            <p className="text-muted-foreground">{t('mentors.subtitle')}</p>
          </div>

          {/* Filters */}
          <Card className="border-border/50 bg-card/50 mb-8">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    {t('mentors.search_placeholder')}
                  </label>
                  <Input
                    placeholder={t('mentors.search_placeholder')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    {t('mentors.filter_university')}
                  </label>
                  <Input
                    placeholder={t('mentors.filter_university')}
                    value={filterUniversity}
                    onChange={(e) => setFilterUniversity(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    {t('mentors.filter_program')}
                  </label>
                  <Input
                    placeholder={t('mentors.filter_program')}
                    value={filterProgram}
                    onChange={(e) => setFilterProgram(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    variant="outline"
                    className="w-full gap-2"
                    onClick={() => {
                      setSearchQuery('');
                      setFilterUniversity('');
                      setFilterProgram('');
                    }}
                  >
                    <Filter className="w-4 h-4" />
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mentors Grid */}
          {filteredMentors.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMentors.map((mentor, idx) => (
                <motion.div
                  key={mentor.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.1 }}
                >
                  <Card className="border-border/50 bg-card/50 hover:bg-card/80 transition-colors h-full flex flex-col">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-4">
                        <Avatar className="w-12 h-12">
                          <AvatarFallback>
                            {mentor.name
                              .split(' ')
                              .map(n => n[0])
                              .join('')}
                          </AvatarFallback>
                        </Avatar>
                        {mentor.isVerified && (
                          <Badge className="bg-blue-500">{t('mentors.view_profile')}</Badge>
                        )}
                      </div>
                      <CardTitle className="text-lg">{mentor.name}</CardTitle>
                      <CardDescription className="text-sm">
                        {mentor.program} @ {mentor.university}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1 space-y-4">
                      <p className="text-sm text-muted-foreground">{mentor.bio}</p>

                      <div>
                        <div className="flex items-center gap-1 mb-2">
                          <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                          <span className="text-sm font-medium">{mentor.rating}</span>
                          <span className="text-xs text-muted-foreground">
                            ({mentor.yearsOfExperience} years mentoring)
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {mentor.expertise.map((skill, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>

                      <Button
                        onClick={() => handleConnect(mentor.id)}
                        disabled={connecting === mentor.id}
                        className="w-full gap-2 bg-blue-600 hover:bg-blue-700 mt-4"
                      >
                        {connecting === mentor.id ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {t('mentors.connect')}
                          </>
                        ) : (
                          <>
                            <MessageSquare className="w-4 h-4" />
                            {t('mentors.connect')}
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <Card className="border-border/50 bg-card/50">
              <CardContent className="pt-6 text-center py-12">
                <p className="text-muted-foreground">{t('mentors.empty_state')}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
